# Bộ bàn giao review · WEB02 · giao diện UI04

Bộ offline này gồm ứng dụng hiện tại, 54 tài liệu VI +54 bản EN, ba bài nháp song ngữ, nguồn học liệu, metadata tham khảo và benchmark/template giả định. [English](README.en.md). Bản giao diện UI04 có tranh vector nguyên bản về hành tinh, người khám phá và đường sao; motion có nút dừng và theo lựa chọn giảm chuyển động của hệ thống. Dành cho diễn tập người lớn với dữ liệu giả; không là phê duyệt giáo dục, pilot với trẻ hay dịch vụ production.

## Mở trên máy

Giải nén nguyên thư mục. Cần Python 3.10+ có sẵn; không cài dependency, không cần tài khoản/API key.

```sh
python3 -B -m http.server 8875 --bind 127.0.0.1 --directory app
```

Mở http://127.0.0.1:8875/#overview, hoặc chạy ./start-local.command. Toggle VI/EN ở đầu trang. Chỉ dùng dữ liệu giả: dữ liệu buổi học và ghi chú reviewer lưu riêng trong trình duyệt; không gửi server/tự đồng bộ giữa người hay máy. Xuất backup hoặc phiếu góp ý JSON để bàn giao có chủ đích; phiếu góp ý chưa có luồng import. Origin offline khác origin Vercel nên không tự có dữ liệu cũ. Preview không là xác thực hay phân quyền.

Link tải ZIP trong app là chức năng bản online; downloads không được lồng vào ZIP này. Bản offline không có bản ZIP tự tải lại. Website: https://thuy-anh-ai-learning.vercel.app/#overview · hướng dẫn: https://thuy-anh-ai-learning.vercel.app/#guide · nguồn: https://github.com/nclamvn/thuy-anh-ai-learning.

## Nội dung và tính toàn vẹn

CONTENT-MANIFEST.json liệt kê SHA-256/byte count của từng file, release WEB02 và fingerprint của bộ nội dung. Nó không tự băm chính nó, không là chữ ký hay bằng chứng hiệu quả. Outer manifest trên website ghi SHA/bytes của ZIP để đối chiếu trước khi giải nén. [Quy trình bàn giao](docs/SHARING-WEB02.md).

Ứng dụng dùng fixture cố ý có lỗi, không gọi live AI. Metadata nghiên cứu giữ URL/capture hash lịch sử; **không chứa raw toàn văn HTML/PDF**. Không có tools compiler/research verifier trong bộ này: corpus thiếu nên full-capture provenance không thể chạy lại. Manifest resources giữ lịch sử compile ban đầu; không được sửa để giả PASS. Dùng public source repo và bộ kiểm public nếu cần công cụ phát triển; bộ này là handoff có thể mở trực tiếp.

Không chứa dữ liệu browser/người tham gia, consent, QA, env/credentials hay phê duyệt người thật. Quyền sử dụng code/tài liệu dự án chưa được chọn license chung; giữ LICENSE/PROVENANCE và font OFL. Review chuyên gia, diễn tập độc lập, product/data/consent và mọi quyết định pilot/live/production còn cần người chịu trách nhiệm.
