# Authored review handoff · WEB02 · R04 references edition

This offline kit contains the current application, 54 Vietnamese documents +54 authored English counterparts, three bilingual draft lessons, material sources, reference metadata and synthetic benchmark/templates. [Vietnamese](README.md). The R04 edition adds a native directory of 14 reference documents and the bilingual research dossier; it retains original planetary/explorer artwork and adds eight purpose-specific illustrated working rooms: group, authoring, session, journal, preparation, library, guide and correspondence, with a pause control and system reduced-motion support. Scope: adult rehearsal with fictional data; no educational approval, child-pilot approval or production-service claim.

## Open locally

Extract the whole directory. Python 3.10+ must already be available; no dependency installation, account or API key is required.

```sh
python3 -B -m http.server 8875 --bind 127.0.0.1 --directory app
```

Open http://127.0.0.1:8875/#overview, or run ./start-local.command. Use the header VI/EN toggle. Enter fictional data only. Learning records and reviewer notes stay separately in browser-local storage, with no server submission or automatic cross-person/device sync. Export a backup or review JSON for deliberate handoff; review JSON has no import flow. Offline and Vercel origins do not share stored records. Learner preview is not authentication or authorization.

The app's ZIP download links belong to the online distribution; downloads are not nested inside this ZIP. The offline kit has no recursively downloadable ZIP. Website: https://thuy-anh-ai-learning.vercel.app/#overview · guide: https://thuy-anh-ai-learning.vercel.app/#guide · source: https://github.com/nclamvn/thuy-anh-ai-learning.

## Contents and integrity

CONTENT-MANIFEST.json records SHA-256/bytes for every file, release WEB02 and a content fingerprint. It does not hash itself and is not a signature or evidence of effectiveness. The online outer manifest records archive SHA/bytes for comparison before extraction. [Handoff protocol](docs/SHARING-WEB02.en.md).

The application uses deliberately flawed fixtures, not live AI. Research metadata preserves URLs/historical capture hashes; **raw HTML/PDF works are excluded**. No compiler/research-verifier tools are included in this kit: unavailable raw corpus prevents full-capture provenance revalidation. The resource manifest preserves the original compile history and must not be altered to fabricate PASS. Use the public source repository/public checks for development tools; this kit is a directly runnable handoff.

No browser/participant data, consent, QA, env/credentials or authenticated human approvals are included. A general project code/document license remains undecided; retain LICENSE/PROVENANCE and font OFL notices. Educational review, independent rehearsal, product/data/consent decisions and any pilot/live-AI/production decisions remain with responsible people.
